﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WPFRegisterStudent
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Course choice;
        private int creditHours = 0; 
        // Establish private variable for amount of credit hours.
        // private to match the parameters of private void button_Click

        public MainWindow()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

            Course course1 = new Course("IT 145");
            Course course2 = new Course("IT 200");
            Course course3 = new Course("IT 201");
            Course course4 = new Course("IT 270");
            Course course5 = new Course("IT 315");
            Course course6 = new Course("IT 328");
            Course course7 = new Course("IT 330");


            this.comboBox.Items.Add(course1);
            this.comboBox.Items.Add(course2);
            this.comboBox.Items.Add(course3);
            this.comboBox.Items.Add(course4);
            this.comboBox.Items.Add(course5);
            this.comboBox.Items.Add(course6);
            this.comboBox.Items.Add(course7);


            this.textBox.Text = "";
        }

        private void button_Click(object sender, RoutedEventArgs e)
        {
            choice = (Course)(this.comboBox.SelectedItem);

            // TO DO - Create code to validate user selection (the choice object)
            // and to display an error or a registation confirmation message accordinlgy
            // Also update the total credit hours textbox if registration is confirmed for a selected course

            if (listBox.Items.Contains(choice)) 
                // if statement to run user input through iterations.
                // listBox references the output box and choice references the user input for course selection.
            {
                label3.Content = "You have already registered for this " + choice + " course."; 
                // To prevent picking the same choice more than once. label3 references the box the registered courses should be output.
            }
            else if (creditHours < 9) 
                // Boolean for less than 9 credit hours selected.
            {
                listBox.Items.Add(choice);
                // listBox references the name of the box the courses will appear in for the UI, choice retrieves the user choice for course.
                creditHours += 3; 
                // This is to add 3 credit hours for each registered course.
                textBox.Text = Convert.ToString(creditHours); 
                // textBox references the box the amount of hours registered should be output. 
                label3.Content = "Registration Confirmed for course " + choice + "."; 
                // Output the confirmation of registered courses selected by the user.
            }
            else
            {   // else to catch iterations that have not yet met criteria.
                label3.Content = "You can not register for more than 9 credit hours."; 
                // To ensure the user does not enroll in more than 9 credit hours.
            }
        }
    }
}
